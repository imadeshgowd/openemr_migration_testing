# Configuration for the test environment

BASE_URL = 'https://demo.openemr.io/openemr'
USERNAME = 'admin'
PASSWORD = 'pass'
DRIVER_PATH = '/path/to/your/chromedriver'  # Ensure this path is correct